# incoming/

Drop a project archive here to publish a new version automatically.

## Usage
1. Name the file with a version: `ApkNamer-v1.0.zip`, `ApkNamer-v1.1.zip`, … (`vMAJOR.MINOR` or `vMAJOR.MINOR.PATCH`).
2. Upload it to this folder (GitHub web: **Add file → Upload files**, or `git add incoming/… && git push`) on the `main` branch.
3. The **Release from incoming zip** workflow then:
   - replaces every project file with the zip contents (the zip may contain a single top-level folder);
   - stamps `versionName` / `versionCode` from the file name (`v1.2.3` → code `10203`);
   - runs the unit tests and builds the APK — **nothing is committed if tests or the build fail**;
   - commits the new project state and creates the GitHub Release `vX.Y`.
4. Download from **Releases**: every release has a single APK named with its version, e.g. `ApkNamer-v1.10.apk` (the "Source code" zip/tar.gz entries are added by GitHub itself and cannot be removed).
   - latest release: `https://github.com/OWNER/ApkNamer/releases/latest`
   - a specific version: `https://github.com/OWNER/ApkNamer/releases/download/v1.10/ApkNamer-v1.10.apk`
