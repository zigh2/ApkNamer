# incoming/

Drop a project archive here to publish a new version automatically.

## Usage
1. Name the file with a version: `ApkNamer-v1.0.zip`, `ApkNamer-v1.1.zip`, … (`vMAJOR.MINOR` or `vMAJOR.MINOR.PATCH`).
2. Upload it to this folder (GitHub web: **Add file → Upload files**, or `git add incoming/… && git push`) on the `main` branch.
3. The **Release from incoming zip** workflow then:
   - replaces every project file with the zip contents (the zip may contain a single top-level folder);
   - stamps `versionName` / `versionCode` from the file name (`v1.2.3` → code `10203`);
   - runs the unit tests and builds the APK — **nothing is committed if tests or the build fail**;
   - commits the new project state and creates the GitHub Release `vX.Y`.
4. Download from **Releases**:
   - latest: `https://github.com/OWNER/ApkNamer/releases/latest/download/ApkNamer.apk`
   - specific: `…/releases/download/v1.0/ApkNamer-v1.0.apk`

Old zips stay in this folder as an archive; delete them if you prefer. Re-run for an existing zip via **Actions → Run workflow**.

## What is NOT replaced
`incoming/` itself, `.git/`, and `.github/workflows/` (GitHub does not allow the default token to modify workflow files).
If a new zip contains workflow changes, copy them manually.

## One-time: signed releases (recommended)
Without a keystore the APK is debug-signed with a throw-away key, so each version has a different signature and Android refuses to update an installed copy. Create a key once:

```bash
keytool -genkeypair -v -keystore release.jks -alias apknamer -keyalg RSA -keysize 4096 -validity 36500
base64 -w0 release.jks      # macOS: base64 -i release.jks
```

Then add these **repository secrets** (Settings → Secrets and variables → Actions):

| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | output of the `base64` command |
| `KEYSTORE_PASSWORD` | keystore password |
| `KEY_ALIAS` | `apknamer` |
| `KEY_PASSWORD` | key password |

Keep `release.jks` backed up somewhere safe — losing it means users can no longer update the app.
